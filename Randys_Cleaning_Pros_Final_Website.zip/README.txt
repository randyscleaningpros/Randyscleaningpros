RANDY'S CLEANING PROS — GITHUB WEBSITE

1. Unzip this package.
2. Upload every file and folder inside to your GitHub repository.
3. Keep the assets folder with the HTML files.
4. In GitHub Pages, publish from the main branch and root folder.
5. Do not upload only index.html.

Main contact:
Phone/Text: 207-558-1298
Email: randyscleaningpros@gmail.com
