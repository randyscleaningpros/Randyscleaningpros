
const toggle=document.querySelector('.menu-toggle');
const menu=document.querySelector('.menu');
if(toggle&&menu){
  toggle.addEventListener('click',()=>{const open=menu.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
  menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{menu.classList.remove('open');toggle.setAttribute('aria-expanded','false');}));
}
const q=document.querySelector('#quoteForm');
if(q){
  q.addEventListener('submit',e=>{
    e.preventDefault();
    const d=new FormData(q);
    let body='FREE QUOTE REQUEST\n\n';
    for(const [k,v] of d.entries()){
      if(v instanceof File){if(v.name) body+=`${k}: ${v.name} (please attach photo manually)\n`;}
      else body+=`${k}: ${v}\n`;
    }
    const subject=encodeURIComponent('Free Quote Request - '+(d.get('name')||'New Customer'));
    location.href='mailto:randyscleaningpros@gmail.com?subject='+subject+'&body='+encodeURIComponent(body);
  });
}
