const t=document.getElementById("toggle"),m=document.getElementById("menu");if(t&&m){t.onclick=()=>{const o=m.classList.toggle("open");t.setAttribute("aria-expanded",String(o))};m.querySelectorAll("a").forEach(a=>a.onclick=()=>{m.classList.remove("open");t.setAttribute("aria-expanded","false")})}document.getElementById("year").textContent=new Date().getFullYear();const f=document.getElementById("quoteForm"),msg=document.getElementById("formMsg");f.addEventListener("submit",e=>{e.preventDefault();const d=new FormData(f),businessEmail="your-business-email@example.com";if(businessEmail.includes("example.com")){msg.textContent="Add your real business email in script.js to activate this form.";msg.style.color="#a33b1f";return}const subject=encodeURIComponent(`Cleaning quote request from ${d.get("name")||""}`),body=encodeURIComponent(`Name: ${d.get("name")||""}
Phone: ${d.get("phone")||""}
Email: ${d.get("email")||""}
Service: ${d.get("service")||""}

Property details:
${d.get("details")||""}`);location.href=`mailto:${businessEmail}?subject=${subject}&body=${body}`});