RANDY'S CLEANING PROS — COMPLETE HOMEPAGE

Included: index.html, styles.css, script.js

Updates:
- New phone number: 1-877-207-3123
- Stronger premium and Gold Standard sales message
- Phone-friendly menu and fixed Call/Text/Quote buttons
- Broken photo sections removed
- Eco section rebuilt as a built-in graphic
- Responsive, accessible layout

FORM SETUP:
Open script.js and replace your-business-email@example.com with the real business email.

GITHUB:
Upload all three website files to the main folder of your GitHub Pages repository.
